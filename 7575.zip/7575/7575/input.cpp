//Test Program
#include<iostream.h>
int main()
{
 float a = 3534.345;
 int b = 500;

 int i = 0 ; 
 while( i <= 6)
 {	    	
   i++;
 }
/* How to add 2 number  
   a = b + c	
*/

}
